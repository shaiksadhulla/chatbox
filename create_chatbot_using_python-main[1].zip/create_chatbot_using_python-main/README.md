# create_chatbot_using_python
This code is an implementation of a simple chatbot using TensorFlow, which is a machine learning framework developed by Google. The chatbot is trained using a neural network to classify user inputs into predefined intents and provide appropriate responses based on the detected intent.
The intents.json file is the data that we will provide to our chatbot 
